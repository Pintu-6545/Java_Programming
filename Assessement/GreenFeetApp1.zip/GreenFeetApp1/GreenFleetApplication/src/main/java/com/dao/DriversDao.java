package com.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import com.bean.DriverView;
import com.bean.Drivers;
import com.bean.Users;
import com.util.GreenFleetUtil;

public class DriversDao {

	public static void insertDrivers(Drivers d)
	{
		try {
			
			Connection conn = GreenFleetUtil.createConnection();
			String sql="insert into driver (user_id,name,license_no,phone_no) values(?,?,?,?)";
			PreparedStatement pst = conn.prepareStatement(sql);
			pst.setInt(1,d.getUser_id());
			pst.setString(2, d.getName());
			pst.setString(3, d.getLicense_no());
			pst.setLong(4, d.getPhone_no());
			pst.executeUpdate();
			
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	public static boolean checkEmail(String email)
	{
		boolean flag =false;
		try {
			Connection conn = GreenFleetUtil.createConnection();
			String sql="select * from driver where email=?";
			PreparedStatement pst = conn.prepareStatement(sql);
			pst.setString(1, email);
			ResultSet rs = pst.executeQuery();
			if(rs.next())
			{
				flag=true;
			}
			//rs.close();
            //pst.close();
           // conn.close();
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		return flag;
	}
		
	public static List<DriverView> getAllDriverDetails() {
	    List<DriverView> list = new ArrayList<>();

	    try {
	        Connection con = GreenFleetUtil.createConnection();

	        String sql =
	            "SELECT d.driver_id, d.name, d.phone_no, d.license_no, " +
	            "u.user_id, u.email, u.password, u.username, u.role, u.status " +
	            "FROM driver d " +
	            "INNER JOIN users u ON d.user_id = u.user_id";

	        PreparedStatement ps = con.prepareStatement(sql);
	        ResultSet rs = ps.executeQuery();

	        while (rs.next()) {
	            DriverView dv = new DriverView();

	            dv.setDriver_id(rs.getInt("driver_id"));
	            dv.setName(rs.getString("name"));
	            dv.setPhone_no(rs.getLong("phone_no"));   
	            dv.setLicense_no(rs.getString("license_no"));

	            dv.setUser_id(rs.getInt("user_id"));
	            dv.setEmail(rs.getString("email"));
	            dv.setPassword(rs.getString("password"));
	            dv.setUsername(rs.getString("username"));
	            dv.setRole(rs.getString("role"));
	            dv.setStatus(rs.getString("status"));

	            list.add(dv);
	        }

	    } catch (Exception e) {
	        e.printStackTrace();
	    }
	    return list;
	}
	
	public static DriverView getByDriver(int userId) {

	    DriverView d = null;

	    try {
	        Connection con = GreenFleetUtil.createConnection();
	        String sql =
	          "SELECT d.driver_id, d.name, d.phone_no, d.license_no, " +
	          "u.user_id, u.email, u.username, u.role, u.status " +
	          "FROM driver d JOIN users u ON d.user_id = u.user_id " +
	          "WHERE u.user_id = ?";

	        PreparedStatement ps = con.prepareStatement(sql);
	        ps.setInt(1, userId);

	        ResultSet rs = ps.executeQuery();

	        if (rs.next()) {
	            d = new DriverView();
	            d.setDriver_id(rs.getInt("driver_id"));
	            d.setName(rs.getString("name"));
	            d.setPhone_no(rs.getLong("phone_no"));
	            d.setLicense_no(rs.getString("license_no"));

	            d.setUser_id(rs.getInt("user_id"));
	            d.setEmail(rs.getString("email"));
	            d.setUsername(rs.getString("username"));
	            d.setRole(rs.getString("role"));
	            d.setStatus(rs.getString("status"));
	        }

	    } catch (Exception e) {
	        e.printStackTrace();
	    }
	    return d;
	}
   
	public static void updateUserAndDriver(Users u, Drivers d) 
	{

	    try {
	       Connection conn = GreenFleetUtil.createConnection();
	        conn.setAutoCommit(false);

	        //  Update Users
	        String sql1 = "UPDATE users SET email=?, username=?, password=?, role=?, status=? WHERE user_id=?";
	        PreparedStatement pst1 = conn.prepareStatement(sql1);
	        pst1.setString(1, u.getEmail());
	        pst1.setString(2, u.getUsername());
	        pst1.setString(3, u.getPassowrd());
	        pst1.setString(4, u.getRole());
	        pst1.setString(5, u.getStatus());
	        pst1.setInt(6, u.getUser_id());
	        pst1.executeUpdate();

	        //  Update Driver (USE driver_id)
	        String sql2 = "UPDATE driver SET name=?, phone_no=?, license_no=? WHERE driver_id=?";
	        PreparedStatement pst2 = conn.prepareStatement(sql2);
	        pst2.setString(1, d.getName());
	        pst2.setLong(2, d.getPhone_no());
	        pst2.setString(3, d.getLicense_no());
	        pst2.setInt(4, d.getDriver_id());
	        pst2.executeUpdate();

	        conn.commit();

	    } catch (Exception e) {
	        
	        e.printStackTrace();
	    }
	}

	public static void deleteDriver(int user_id) {
	    try {
	        Connection conn = GreenFleetUtil.createConnection();

	        // 1️⃣ Delete from driver table (child)
	        String driverSql = "DELETE FROM driver WHERE user_id = ?";
	        PreparedStatement psDriver = conn.prepareStatement(driverSql);
	        psDriver.setInt(1, user_id);
	        psDriver.executeUpdate();

	        // 2️⃣ Delete from users table (parent)
	        String userSql = "DELETE FROM users WHERE user_id = ?";
	        PreparedStatement psUser = conn.prepareStatement(userSql);
	        psUser.setInt(1, user_id);
	        psUser.executeUpdate();

	        conn.close();
	    } catch (Exception e) {
	        e.printStackTrace();
	    }
	}
	
	public static Drivers getDriverById(int driver_id) {
	    Drivers d = null;

	    try {
	        Connection conn = GreenFleetUtil.createConnection();
	        String sql = "SELECT * FROM driver WHERE driver_id=?";
	        PreparedStatement ps = conn.prepareStatement(sql);
	        ps.setInt(1, driver_id);

	        ResultSet rs = ps.executeQuery();

	        if (rs.next()) {
	            d = new Drivers();
	            d.setDriver_id(rs.getInt("driver_id"));
	            d.setName(rs.getString("name"));
	        }

	    } catch (Exception e) {
	        e.printStackTrace();
	    }
	    return d;
	}


}
